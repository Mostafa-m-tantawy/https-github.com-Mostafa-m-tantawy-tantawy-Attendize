

<?php $__env->startSection('head'); ?>
    <?php
        App::setLocale('ar');
    ?>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css"
          integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('Public.ViewEvent.Partials.EventHeaderSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('Public.ViewEvent.Partials.EventCreateOrderSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>var OrderExpires = <?php echo e(strtotime($expires)); ?>;</script>
    <?php echo $__env->make('Public.ViewEvent.Partials.EventFooterSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    
    <script>

        $('document').ready(function () {
            $('#university_id').on('change', function () {
                if ($(this).find(':selected').data('stud_domain')) {
                    $(' #type ').html(
                        `                      <option  value="stud_domain">طالب /طالبة</option>`
                    )
                }
                if ($(this).find(':selected').data('staff_domain')) {
                    $(' #type ').html(
                        ` <option value="staff_domain">عضو هيئه تدريس</option>
                                <option value="employee_domain">موظف / موظفة</option>`
                    )
                }
            });

            $('#university_id , #type ').on('change', function () {
                if ($('#type').val() == 'stud_domain'){
                    $('#domainHTML').html($('#university_id').find(':selected').data('stud_domain')+'@');
                    $('#domain').val($('#university_id').find(':selected').data('stud_domain'));

                }
                else {
                    $('#domainHTML').html($('#university_id').find(':selected').data('staff_domain')+'@');
                    $('#domain').val($('#university_id').find(':selected').data('staff_domain'));
                }


            });


            // $('.order_last_name').on('input', function () {
            //     $('.ticket_holder_first_name').val($(this).val());
            // });
            $('.order_first_name').on('input', function () {
                $('.ticket_holder_first_name').val($(this).val());

            });
            $('.order_email').on('input', function () {
                $('.ticket_holder_email').val($(this).val());

            });
            $('.order_phone').on('input', function () {
                $('.ticket_holder_phone').val($(this).val());

            });
            $('.order_university_id').on('input', function () {
                $('.ticket_holder_university_id').val($(this).val());

            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Public.ViewEvent.Layouts.EventPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tantawy-Attendize\resources\views/Public/ViewEvent/EventPageCheckout.blade.php ENDPATH**/ ?>