<div class="panel panel-success event">
    <div class="panel-heading" data-style="background-color: <?php echo e($university->bg_color); ?>;background-image: url(<?php echo e($university->bg_image_url); ?>); background-size: cover;">

        <ul class="event-meta">
            <li class="event-title">
University            </li>
            <li class="event-organiser">
                By <a href='<?php echo e(route('showOrganiserDashboard', ['organiser_id' => $university->organiser->id])); ?>'><?php echo e($university->organiser->name); ?></a>
            </li>
        </ul>

    </div>

    <div class="panel-body">
        <ul class="nav nav-section nav-justified mt5 mb5">
            <li>
                <div class="section">
                    <h4 class="nm"><?php echo e($university->name); ?></h4>
                    <p class="nm text-muted">University</p>
                </div>
            </li>

            <li>
                <div class="section">
                    <h4 class="nm"><?php echo e($university->attendance_limit); ?></h4>
                    <p class="nm text-muted">University Limit</p>
                </div>
            </li>


        </ul>
        <ul class="nav nav-section nav-justified mt5 mb5">
        <li>
            <div class="section">
                <h4 class="nm"><?php echo e($university->stud_domain); ?></h4>
                <p class="nm text-muted">Student Domain</p>
            </div>
        </li>
            <li>
            <div class="section">
                <h4 class="nm"><?php echo e($university->staff_domain); ?></h4>
                <p class="nm text-muted">Staff Domain</p>
            </div>
        </li>
        </ul>

    </div>
    <div class="panel-footer">
        <ul class="nav nav-section nav-justified">
            <li>
                <a href="#" data-modal-id="editUniversity"
                   data-href="<?php echo e(route('showUpdateUniversity', ['university_id' => $university->id])); ?>"
                   class=" loadModal">      <i class="ico-edit"></i>   <?php echo app('translator')->get("basic.edit"); ?> University</a>


            </li>

        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\tantawy-Attendize\resources\views/ManageOrganiser/Partials/UniversityPanel.blade.php ENDPATH**/ ?>