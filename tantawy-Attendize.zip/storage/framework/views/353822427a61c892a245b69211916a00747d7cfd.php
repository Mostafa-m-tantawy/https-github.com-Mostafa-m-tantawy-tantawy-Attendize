

Powered By <a style="color: #FFF;" title="Attendize - Sell Tickets Online" href="https://www.attendize.com/?powered_by">Attendize</a>
<?php /**PATH C:\xampp\htdocs\tantawy-Attendize\resources\views/Shared/Partials/PoweredBy.blade.php ENDPATH**/ ?>