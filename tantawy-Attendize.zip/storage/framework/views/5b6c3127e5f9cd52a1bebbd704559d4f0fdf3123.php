<h3><?php echo app('translator')->get("Public_ViewEvent.payment_information"); ?></h3>
<?php echo app('translator')->get("Public_ViewEvent.below_payment_information_header"); ?>
<?php if($event->enable_offline_payments): ?>
<?php echo Form::open(['url' => route('postCreateOrder', ['event_id' => $event->id]), 'class' => 'ajax']); ?>

<div class="offline_payment_toggle">
    <div class="custom-checkbox">
        <?php if($payment_gateway === false): ?>
        
        <input type="hidden" name="pay_offline" value="1">
        <input id="pay_offline" type="checkbox" value="1" checked disabled>
        <?php else: ?>
        <input data-toggle="toggle" id="pay_offline" name="pay_offline" type="checkbox" value="1">
        <?php endif; ?>
        <label for="pay_offline"><?php echo app('translator')->get("Public_ViewEvent.pay_using_offline_methods"); ?></label>
    </div>
</div>
<div class="offline_payment" style="display: none;">
    <h5><?php echo app('translator')->get("Public_ViewEvent.offline_payment_instructions"); ?></h5>
    <div class="well">
        <?php echo md_to_html($event->offline_payment_instructions); ?>

    </div>
    <input class="btn btn-lg btn-success card-submit" style="width:100%;" type="submit" value="<?php echo app('translator')->get("Public_ViewEvent.complete_order"); ?>">
</div>
<?php echo Form::close(); ?>

<style>
    .offline_payment_toggle {
        padding: 20px 0;
    }
</style>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tantawy-Attendize\resources\views/Public/ViewEvent/Partials/OfflinePayments.blade.php ENDPATH**/ ?>