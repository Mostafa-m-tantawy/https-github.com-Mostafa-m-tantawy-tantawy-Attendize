<section id='order_form' class="container">
    <div class="row">
        <h1 class="section_head">
            <?php echo app('translator')->get("Public_ViewEvent.order_details"); ?>
        </h1>
    </div>
    <div class="row">
        <div class="col-md-12" style="text-align: center">
            <?php echo app('translator')->get("Public_ViewEvent.below_order_details_header"); ?>
        </div>
        <div class="col-md-4 col-md-push-8">
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <i class="ico-cart mr5"></i>
                        <?php echo app('translator')->get("Public_ViewEvent.order_summary"); ?>
                    </h3>
                </div>

                <div class="panel-body pt0">
                    <table class="table mb0 table-condensed">
                        <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="pl0"><?php echo e($ticket['ticket']['title']); ?> X <b><?php echo e($ticket['qty']); ?></b></td>
                                <td style="text-align: right;">
                                    <?php if (\Illuminate\Support\Facades\Blade::check('isFree', $ticket['full_price'])): ?>
                                    <?php echo app('translator')->get("Public_ViewEvent.free"); ?>
                                    <?php else: ?>
                                        <?php echo e(money($ticket['full_price'], $event->currency)); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <?php if($order_total > 0): ?>
                    <div class="panel-footer">
                        <h5>
                            <?php echo app('translator')->get("Public_ViewEvent.total"); ?>: <span
                                style="float: left;"><b><?php echo e($orderService->getOrderTotalWithBookingFee(true)); ?></b></span>
                        </h5>
                        <?php if($event->organiser->charge_tax): ?>
                            <h5>
                                <?php echo e($event->organiser->tax_name); ?> (<?php echo e($event->organiser->tax_value); ?>%):
                                <span style="float: right;"><b><?php echo e($orderService->getTaxAmount(true)); ?></b></span>
                            </h5>
                            <h5>
                                <strong><?php echo app('translator')->get("Public_ViewEvent.grand_total"); ?></strong>
                                <span style="float: left;"><b><?php echo e($orderService->getGrandTotal(true)); ?></b></span>
                            </h5>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            </div>
            <div class="help-block">
                <?php echo @trans("Public_ViewEvent.time", ["time"=>"<span id='countdown'></span>"]); ?>

            </div>
        </div>
        <div class="col-md-8 col-md-pull-4">
            <div class="event_order_form">
                <?php echo Form::open(['url' => route('postValidateOrder', ['event_id' => $event->id ]), 'class' => 'ajax payment-form', 'id' => 'payment-form']); ?>


                <?php echo Form::hidden('event_id', $event->id); ?>


                <h3> <?php echo app('translator')->get("Public_ViewEvent.your_information"); ?></h3>

                <div class="row">

                    <div class="col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label("order_first_name", trans("Public_ViewEvent.first_name")); ?>

                            <?php echo Form::text("order_first_name", null, ['required' => 'required', 'class' => 'form-control order_first_name']); ?>

                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label("order_faculty", trans("Public_ViewEvent.faculty")); ?>

                            <?php echo Form::text("order_faculty", null, ['required' => 'required', 'class' => 'form-control order_faculty']); ?>

                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-xs-12">
                        <div class="form-group">
                            <?php echo Form::label("order_phone", trans("Public_ViewEvent.order_phone")); ?>

                            <?php echo Form::number("order_phone", null, ['required' => 'required', 'class' => 'form-control order_phone']); ?>

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-6">
                        <div class="form-group">
                            <?php echo Form::label("university", "الجامعة"); ?>

                            <select name="order_university_id" id="university_id" class="form-control order_university_id" required>
                                <?php $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $university): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option data-staff_domain="<?php echo e($university->staff_domain); ?>"
                                            data-stud_domain="<?php echo e($university->stud_domain); ?>"
                                            value="<?php echo e($university->id); ?>"><?php echo e($university->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-6">
                        <div class="form-group">
                            <?php echo Form::label("order_type", "النوع"); ?>

                            <select name="order_type" id="type" class="form-control order_type" required>
                                <?php if($universities->first()->staff_domain): ?>
                                    <option value="staff_domain">عضو هيئه تدريس</option>
                                    <option value="employee_domain">موظف / موظفة</option>
                                <?php endif; ?>
                                <?php if($universities->first()->stud_domain): ?>
                                    <option value="stud_domain">طالب /طالبة</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12">

                        <div class="input-group mb-3">
                            <?php echo Form::label("order_email", trans("Public_ViewEvent.email")); ?>

                            <div class="input-group">
                                <div class="input-group-addon"
                                     id="domainHTML"><?php echo e($universities->first()->stud_domain??$universities->first()->staff_domain); ?>@
                                </div>
                                <input class="form-control order_email" name="order_email" required placeholder="email">
                            </div>
                        </div>
                        <input type="hidden" name="domain" id="domain" value="<?php echo e($universities->first()->stud_domain??$universities->first()->staff_domain); ?>">
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-12">
                        <script src="https://www.google.com/recaptcha/api.js?hl=ar" async defer></script>
                        <div class="g-recaptcha" data-sitekey="<?php echo e(config('attendize.captcha.captcha_key')); ?>"></div>


                    </div>
                </div>
                
                
                
                
                
                
                
                
                
                
                
                <div class="row">
                    <div class="col-md-12">&nbsp;</div>
                </div>
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

                <div class="row" hidden="">
                    <div class="col-md-12">
                        <div class="ticket_holders_details">
                            <h3><?php echo app('translator')->get("Public_ViewEvent.ticket_holder_information"); ?></h3>
                            <?php
                            $total_attendee_increment = 0;
                            ?>
                            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php for($i=0; $i<=$ticket['qty']-1; $i++): ?>
                                    <div class="panel panel-primary">

                                        <div class="panel-heading">
                                            <h3 class="panel-title">
                                                <b><?php echo e($ticket['ticket']['title']); ?></b>: <?php echo app('translator')->get("Public_ViewEvent.ticket_holder_n", ["n"=>$i+1]); ?>
                                            </h3>
                                        </div>
                                        <div class="panel-body">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <?php echo Form::label("ticket_holder_first_name[{$i}][{$ticket['ticket']['id']}]", trans("Public_ViewEvent.first_name")); ?>

                                                        <?php echo Form::text("ticket_holder_first_name[{$i}][{$ticket['ticket']['id']}]", null, [ 'class' => "ticket_holder_first_name.$i.{$ticket['ticket']['id']} ticket_holder_first_name form-control"]); ?>

                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <?php echo Form::label("ticket_holder_last_name[{$i}][{$ticket['ticket']['id']}]", trans("Public_ViewEvent.last_name")); ?>

                                                        <?php echo Form::text("ticket_holder_last_name[{$i}][{$ticket['ticket']['id']}]", null, [ 'class' => "ticket_holder_last_name.$i.{$ticket['ticket']['id']} ticket_holder_last_name form-control"]); ?>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <?php echo Form::label("ticket_holder_email[{$i}][{$ticket['ticket']['id']}]", trans("Public_ViewEvent.email_address")); ?>

                                                        <?php echo Form::text("ticket_holder_email[{$i}][{$ticket['ticket']['id']}]", null, ['class' => "ticket_holder_email.$i.{$ticket['ticket']['id']} ticket_holder_email form-control"]); ?>

                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <?php echo Form::label("ticket_holder_phone[{$i}][{$ticket['ticket']['id']}]", trans("Public_ViewEvent.phone")); ?>

                                                        <?php echo Form::text("ticket_holder_phone[{$i}][{$ticket['ticket']['id']}]", null, [ 'class' => "ticket_holder_phone.$i.{$ticket['ticket']['id']} ticket_holder_phone form-control"]); ?>

                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <?php echo Form::label("ticket_holder_university_id[{$i}][{$ticket['ticket']['id']}]", trans("Public_ViewEvent.university_id")); ?>

                                                        <?php echo Form::text("ticket_holder_university_id[{$i}][{$ticket['ticket']['id']}]", null, [ 'class' => "ticket_holder_university_id.$i.{$ticket['ticket']['id']} ticket_holder_university_id form-control"]); ?>

                                                    </div>
                                                </div>
                                                <?php echo $__env->make('Public.ViewEvent.Partials.AttendeeQuestions', ['ticket' => $ticket['ticket'],'attendee_number' => $total_attendee_increment++], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endfor; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <?php if($event->pre_order_display_message): ?>
                    <div class="well well-small">
                        <?php echo nl2br(e($event->pre_order_display_message)); ?>

                    </div>
                <?php endif; ?>

                <?php echo Form::hidden('is_embedded', $is_embedded); ?>

                <?php echo Form::submit(trans("Public_ViewEvent.checkout_order"), ['class' => 'btn btn-lg btn-success card-submit', 'style' => 'width:100%;']); ?>

                <?php echo Form::close(); ?>


            </div>
        </div>
    </div>
    <img src="https://cdn.attendize.com/lg.png"/>
</section>
<?php if(session()->get('message')): ?>
    <script>showMessage('<?php echo e(session()->get('message')); ?>');</script>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\tantawy-Attendize\resources\views/Public/ViewEvent/Partials/EventCreateOrderSection.blade.php ENDPATH**/ ?>