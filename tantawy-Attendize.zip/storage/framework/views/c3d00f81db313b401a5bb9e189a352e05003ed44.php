

<?php $__env->startSection('message_content'); ?>
<?php echo app('translator')->get("basic.hello"); ?>,<br><br>

<?php echo @trans("Order_Emails.successful_order", ["name"=>$order->event->title]); ?><br><br>

<?php echo e(@trans("Order_Emails.tickets_attached")); ?> <a href="<?php echo e(route('showOrderDetails', ['order_reference' => $order->order_reference])); ?>"><?php echo e(route('showOrderDetails', ['order_reference' => $order->order_reference])); ?></a>.

<?php if(!$order->is_payment_received): ?>
<br><br>
<strong><?php echo e(@trans("Order_Emails.order_still_awaiting_payment")); ?></strong>
<br><br>
<?php echo e($order->event->offline_payment_instructions); ?>

<br><br>
<?php endif; ?>

<h3>Order Details</h3>
Order Reference: <strong><?php echo e($order->order_reference); ?></strong><br>
Order Name: <strong><?php echo e($order->full_name); ?></strong><br>
Order Date: <strong><?php echo e($order->created_at->format(config('attendize.default_datetime_format'))); ?></strong><br>
Order Email: <strong><?php echo e($order->email); ?></strong><br>
<a href="<?php echo route('downloadCalendarIcs', ['event_id' => $order->event->id]); ?>">أضف إلى التقويم</a>

<?php if($order->is_business): ?>
<h3>تفاصيل العمل</h3>
<?php if($order->business_name): ?> <?php echo app('translator')->get("Public_ViewEvent.business_name"); ?>: <strong><?php echo e($order->business_name); ?></strong><br><?php endif; ?>
<?php if($order->business_tax_number): ?> <?php echo app('translator')->get("Public_ViewEvent.business_tax_number"); ?>: <strong><?php echo e($order->business_tax_number); ?></strong><br><?php endif; ?>
<?php if($order->business_address_line_one): ?> <?php echo app('translator')->get("Public_ViewEvent.business_address_line1"); ?>: <strong><?php echo e($order->business_address_line_one); ?></strong><br><?php endif; ?>
<?php if($order->business_address_line_two): ?> <?php echo app('translator')->get("Public_ViewEvent.business_address_line2"); ?>: <strong><?php echo e($order->business_address_line_two); ?></strong><br><?php endif; ?>
<?php if($order->business_address_state_province): ?> <?php echo app('translator')->get("Public_ViewEvent.business_address_state_province"); ?>: <strong><?php echo e($order->business_address_state_province); ?></strong><br><?php endif; ?>
<?php if($order->business_address_city): ?> <?php echo app('translator')->get("Public_ViewEvent.business_address_city"); ?>: <strong><?php echo e($order->business_address_city); ?></strong><br><?php endif; ?>
<?php if($order->business_address_code): ?> <?php echo app('translator')->get("Public_ViewEvent.business_address_code"); ?>: <strong><?php echo e($order->business_address_code); ?></strong><br><?php endif; ?>
<?php endif; ?>

<h3> عناصر الطلب</h3>
<div style="padding:10px; background: #F9F9F9; border: 1px solid #f1f1f1;">
    <table style="width:100%; margin:10px;">
        <tr>
            <td>
                <strong>تذكره</strong>
            </td>
            <td>
                <strong>الكمية</strong>
            </td>
            <td>
                <strong>السعر</strong>
            </td>
            <td>
                <strong>مصاريف</strong>
            </td>
            <td>
                <strong>الاجمالي</strong>
            </td>
        </tr>
        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($order_item->title); ?></td>
            <td><?php echo e($order_item->quantity); ?></td>
            <td>
                <?php if (\Illuminate\Support\Facades\Blade::check('isFree', $order_item->unit_price)): ?>
                مجاني
                <?php else: ?>
                <?php echo e(money($order_item->unit_price, $order->event->currency)); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if (\Illuminate\Support\Facades\Blade::check('isFree', $order_item->unit_price)): ?>
                -
                <?php else: ?>
                <?php echo e(money($order_item->unit_booking_fee, $order->event->currency)); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if (\Illuminate\Support\Facades\Blade::check('isFree', $order_item->unit_price)): ?>
                مجاني
                <?php else: ?>
                <?php echo e(money(($order_item->unit_price + $order_item->unit_booking_fee) * ($order_item->quantity),
                $order->event->currency)); ?>

                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="3"></td>
            <td><strong>المجموع الفرعي</strong></td>
            <td colspan="2">
                <?php echo e($orderService->getOrderTotalWithBookingFee(true)); ?>

            </td>
        </tr>
        <?php if($order->event->organiser->charge_tax == 1): ?>
        <tr>
            <td colspan="3"></td>
            <td>
                <strong><?php echo e($order->event->organiser->tax_name); ?></strong><em>(<?php echo e($order->event->organiser->tax_value); ?>%)</em>
            </td>
            <td colspan="2">
                <?php echo e($orderService->getTaxAmount(true)); ?>

            </td>
        </tr>
        <?php endif; ?>
        <tr>
            <td colspan="3"></td>
            <td><strong>الاجمالي</strong></td>
            <td colspan="2">
                <?php echo e($orderService->getGrandTotal(true)); ?>

            </td>
        </tr>
    </table>
    <br><br>
</div>
<br><br>
Thank you
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Emails.Layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tantawy-Attendize\resources\views/Emails/OrderConfirmation.blade.php ENDPATH**/ ?>