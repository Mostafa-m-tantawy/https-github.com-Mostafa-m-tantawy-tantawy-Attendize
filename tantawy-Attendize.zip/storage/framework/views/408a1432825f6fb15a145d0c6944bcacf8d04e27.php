

<?php $__env->startSection('message_content'); ?>
    <pre>
مرحباً : <?php echo e($order->full_name); ?>

سعدنا بتسجيلك للقاء الحواري : <?php echo e($order->event->title); ?>


مرفق لكم من خلال هذا البريد تذكرة الحضور
<a href="<?php echo e(route('showOrderTickets', ['order_reference' => $order->order_reference])); ?>"><?php echo e(route('showOrderDetails', ['order_reference' => $order->order_reference])); ?></a>

لإضافة موعد اللقاء للتقويم
<a href="<?php echo route('downloadCalendarIcs', ['event_id' => $order->event->id]); ?>">أضف إلى التقويم</a>
يوجد شهادات حضور لمن يقوم بتعبئة نموذوج استطلاع الرآي
رابط نموذج الاستطلاع سيرسل لكم عبر البريد

سيتم احتساب حضور الجلسات في سجل مهاري لطلبة جامعة الملك سعود


شاكرين ومقدرين لكم أهتمامكم
والله يحفظكم ويرعاكم،،،

    </pre>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Emails.Layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tantawy-Attendize\resources\views/Emails/OrderConfirmationArabic.blade.php ENDPATH**/ ?>