<div role="dialog" class="modal fade" style="display: none;">
    <style>
        .well.nopad {
            padding: 0px;
        }
    </style>

    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h3 class="modal-title">
                    <i class="ico-cart"></i>
                    <?php echo e(@trans("ManageEvent.manage_order_title", ["order_ref"=>$order->order_reference])); ?>

                </h3>
            </div>
            <div class="modal-body">

                <?php if($order->is_refunded || $order->is_partially_refunded): ?>
                    <div class="alert alert-info">
                        <?php echo app('translator')->get("ManageEvent.order_refunded", ["money"=>money($order->amount_refunded, $order->event->currency)]); ?>
                    </div>
                <?php endif; ?>

                <?php if(!$order->is_payment_received): ?>
                    <div class="alert alert-info">
                        <?php echo app('translator')->get("ManageEvent.this_order_is_awaiting_payment"); ?>
                    </div>
                    <a data-id="<?php echo e($order->id); ?>"
                       data-route="<?php echo e(route('postMarkPaymentReceived', ['order_id' => $order->id])); ?>"
                       class="btn btn-primary btn-sm markPaymentReceived"
                       href="javascript:void(0);"><?php echo app('translator')->get("ManageEvent.mark_payment_received"); ?></a>
                <?php endif; ?>

                <h3><?php echo app('translator')->get("ManageEvent.order_overview"); ?></h3>
                <style>
                    .order_overview b {
                        text-transform: uppercase;
                    }

                    .order_overview .col-sm-4 {
                        margin-bottom: 10px;
                    }
                </style>
                <div class="p0 well bgcolor-white order_overview">
                    <div class="row">
                        <div class="col-sm-6 col-xs-6">
                            <b><?php echo app('translator')->get("Attendee.first_name"); ?></b><br> <?php echo e($order->first_name); ?>

                        </div>
                        <div class="col-sm-6 col-xs-6">
                            <b><?php echo app('translator')->get("Attendee.last_name"); ?></b><br> <?php echo e($order->last_name); ?>

                        </div>

                        <div class="col-sm-6 col-xs-6">
                            <?php if($order->is_refunded): ?>
                                <b><?php echo app('translator')->get("ManageEvent.refunded_amount"); ?></b><br>
                                <?php echo e($order->getRefundedAmountIncludingTax()->display()); ?>

                            <?php else: ?>
                                <b><?php echo app('translator')->get("ManageEvent.amount"); ?></b><br>
                                <?php echo e($order->getOrderAmount()->display()); ?>

                                <?php if($order->is_partially_refunded): ?>
                                    <em>(<?php echo e($order->getPartiallyRefundedAmount()->negate()->display()); ?>)</em>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <div class="col-sm-6 col-xs-6">
                            <b><?php echo app('translator')->get("Order.order_ref"); ?></b><br> <?php echo e($order->order_reference); ?>

                        </div>
                        <div class="col-sm-6 col-xs-6">
                            <b><?php echo app('translator')->get("Order.date"); ?></b><br> <?php echo e($order->created_at->format(config('attendize.default_datetime_format'))); ?>

                        </div>
                        <div class="col-sm-6 col-xs-6">
                            <b><?php echo app('translator')->get("Order.email"); ?></b><br> <?php echo e($order->email); ?>

                        </div>

                        <?php if($order->transaction_id): ?>
                            <div class="col-sm-6 col-xs-6">
                                <b><?php echo app('translator')->get("Order.transaction_id"); ?></b><br> <?php echo e($order->transaction_id); ?>

                            </div>
                            <div class="col-sm-6 col-xs-6">
                                <b><?php echo app('translator')->get("Order.payment_gateway"); ?></b><br> <a
                                        href="<?php echo e($order->payment_gateway->provider_url); ?>"
                                        target="_blank"><?php echo e($order->payment_gateway->provider_name); ?></a>
                            </div>
                        <?php endif; ?>

                        <?php if($order->payment_intent): ?>
                            <div class="col-sm-6 col-xs-6">
                                <b><?php echo app('translator')->get("Order.payment_intent"); ?></b><br> <?php echo e($order->payment_intent); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($order->is_business): ?>
                            <div class="col-sm-6 col-xs-6">
                                <b><?php echo app('translator')->get("Public_ViewEvent.business_name"); ?></b><br/>
                                <?php echo e($order->business_name); ?>

                            </div>
                            <div class="col-sm-6 col-xs-6">
                                <b><?php echo app('translator')->get("Public_ViewEvent.business_tax_number"); ?></b><br/>
                                <?php echo e($order->business_tax_number); ?>

                            </div>
                            <div class="col-sm-6 col-xs-6">
                                <b><?php echo app('translator')->get("Public_ViewEvent.business_address"); ?></b><br/>
                                <?php echo e($order->business_address); ?>

                                <?php if($order->business_address_line_one): ?> <?php echo e($order->business_address_line_one); ?>,<?php endif; ?>
                                <?php if($order->business_address_line_one): ?> <?php echo e($order->business_address_line_two); ?>,<?php endif; ?>
                                <?php if($order->business_address_line_one): ?> <?php echo e($order->business_address_state_province); ?>

                                ,<?php endif; ?>
                                <?php if($order->business_address_line_one): ?> <?php echo e($order->business_address_city); ?>,<?php endif; ?>
                                <?php if($order->business_address_line_one): ?> <?php echo e($order->business_address_code); ?><?php endif; ?>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>

                <h3><?php echo app('translator')->get('Order.order_items'); ?></h3>
                <div class="well nopad bgcolor-white p0">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                            <th><?php echo app('translator')->get("Order.ticket"); ?></th>
                            <th><?php echo app('translator')->get("Order.quantity"); ?></th>
                            <th><?php echo app('translator')->get("Order.price"); ?></th>
                            <th><?php echo app('translator')->get("Order.booking_fee"); ?></th>
                            <th><?php echo app('translator')->get("Order.total"); ?></th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order_item->title); ?></td>
                                    <td><?php echo e($order_item->quantity); ?></td>
                                    <td>
                                        <?php if (\Illuminate\Support\Facades\Blade::check('isFree', $order_item->unit_price)): ?>
                                            <?php echo app('translator')->get("Order.free"); ?>
                                        <?php else: ?>
                                            <?php echo e(money($order_item->unit_price, $order->event->currency)); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (\Illuminate\Support\Facades\Blade::check('isFree', $order_item->unit_price)): ?>
                                            -
                                        <?php else: ?>
                                            <?php echo e(money($order_item->unit_booking_fee, $order->event->currency)); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (\Illuminate\Support\Facades\Blade::check('isFree', $order_item->unit_price)): ?>
                                            <?php echo app('translator')->get("Order.free"); ?>
                                        <?php else: ?>
                                            <?php echo e(money(($order_item->unit_price + $order_item->unit_booking_fee) * ($order_item->quantity), $order->event->currency)); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="3"></td>
                                <td><b><?php echo app('translator')->get("Order.sub_total"); ?></b></td>
                                <td colspan="2"><?php echo e(money($order->total_amount, $order->event->currency)); ?></td>
                            </tr>
                            <?php if($order->event->organiser->charge_tax): ?>
                                <tr>
                                    <td colspan="3"></td>
                                    <td><strong><?php echo e($order->event->organiser->tax_name); ?></strong></td>
                                    <td colspan="2"><?php echo e($order->getOrderTaxAmount()->format()); ?></td>
                                </tr>
                            <?php endif; ?>
                            <tr>
                                <td colspan="3"></td>
                                <td><strong><?php echo app('translator')->get("Order.total"); ?></strong></td>
                                <td colspan="2"><?php echo e($order->getOrderAmount()->add($order->getOrderTaxAmount())->format()); ?></td>
                            </tr>
                            </tbody>
                        </table>

                    </div>
                </div>

                <h3>
                    <?php echo app('translator')->get("Order.order_attendees"); ?>
                </h3>
                <div class="well nopad bgcolor-white p0">

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <tbody>
                            <?php $__currentLoopData = $order->attendees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php if($attendee->is_cancelled): ?>
                                            <span class="label label-warning">
                                            <?php echo app('translator')->get("Order.attendee_cancelled"); ?>
                                        </span>
                                        <?php endif; ?>
                                        <?php if($attendee->is_refunded): ?>
                                            <span class="label label-danger">
                                                <?php echo app('translator')->get("Order.attendee_refunded"); ?>
                                            </span>
                                        <?php endif; ?>
                                        <?php echo e($attendee->first_name); ?>

                                        <?php echo e($attendee->last_name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($attendee->email); ?>

                                    </td>
                                    <td>
                                        <?php echo e($attendee->ticket->title); ?>

                                        <?php echo e($order->order_reference); ?>-<?php echo e($attendee->reference_index); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- /end modal body-->

            <div class="modal-footer">
                <a href="javascript:void(0);" data-modal-id="edit-order-<?php echo e($order->id); ?>"
                   data-href="<?php echo e(route('showEditOrder', ['order_id'=>$order->id])); ?>" title="Edit Order"
                   class="btn btn-info loadModal">
                    <?php echo app('translator')->get("Order.edit"); ?>
                </a>
                <a class="btn btn-primary" target="_blank"
                   href="<?php echo e(route('showOrderTickets', ['order_reference' => $order->order_reference])); ?>"><?php echo app('translator')->get("ManageEvent.print_tickets"); ?></a>
                <span class="pauseTicketSales btn btn-success" data-id="<?php echo e($order->id); ?>"
                      data-route="<?php echo e(route('resendOrder', ['order_id'=>$order->id])); ?>"><?php echo app('translator')->get("ManageEvent.resend_tickets"); ?></span>
                <?php echo Form::button(trans("ManageEvent.close"), ['class'=>"btn modal-close btn-danger",'data-dismiss'=>'modal']); ?>

            </div>
        </div><!-- /end modal content-->
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\tantawy-Attendize\resources\views/ManageEvent/Modals/ManageOrder.blade.php ENDPATH**/ ?>