<?php if(config('attendize.captcha.captcha_is_on') && config('attendize.captcha.captcha_secret')): ?>
<div class="form-group ">
    <?php if(config('attendize.captcha.captcha_type') == 'recaptcha'): ?>
        <?php echo $__env->make('Public.LoginAndRegister.Partials.CaptchaRecaptcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(config('attendize.captcha.captcha_type') == 'hcaptcha'): ?>
        <?php echo $__env->make('Public.LoginAndRegister.Partials.CaptchaHcaptcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tantawy-Attendize\resources\views/Public/LoginAndRegister/Partials/CaptchaSection.blade.php ENDPATH**/ ?>